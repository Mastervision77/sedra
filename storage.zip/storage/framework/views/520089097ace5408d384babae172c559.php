<?php
$setting = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($blogs && $blogs->first()->title != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$blogs->first()->title), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('og_title', @$setting->sitename . " | "."Blog"); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($blogs && $blogs->first()->title != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$blogs->first()->title), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('title', @$setting->sitename . " | "."Blog"); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="pt-11 md:pt-28 pb-20 bg-accent">
    <div class="container mx-auto px-4 text-center mb-16">
        <h1 class="text-5xl md:text-6xl font-bold font-PlayFair mb-6"><?php echo e($setting->title_blog_home); ?></h1>
        <p class="text-xl text-gray-600 max-w-2xl mx-auto">
            <?php echo e($setting->sub_title_blog_home); ?>

        </p>
    </div>

    <!-- Blog Grid -->
    <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

        <!-- Blog Post 1 -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($blogs): ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blogDetails',$blog->slug)); ?>"
                    class="overflow-hidden group cursor-pointer hover:shadow-lg transition-all duration-500 h-full flex flex-col bg-white rounded-lg">
                    <div class="relative h-64 overflow-hidden">
                        <img src="<?php echo e(asset('storage/'.$blog->outerimage)); ?>"
                            alt="Top 10 Hidden Gems in Europe"
                            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <div class="p-6 flex-1 flex flex-col">
                        <h3 class="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                            <?php echo e($blog->title); ?>

                        </h3>
                        <p class="text-gray-600 mb-4 flex-1">
                            <?php echo $blog->subtitle; ?>

                        </p>
                        <div class="flex items-center justify-between text-sm text-gray-500 border-t border-gray-200 pt-4">
                            <div class="flex items-center gap-2">
                                <i class="fa-solid fa-user"></i>
                                <span><?php echo e($blog->author); ?></span>
                            </div>
                            <div class="flex items-center gap-2">
                                <i class="fa-solid fa-calendar-days"></i>
                                <span><?php echo e($blog->date); ?></span>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
    <div class="flex justify-center mt-12 custom-pagination">
        <?php echo e($blogs->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/blog.blade.php ENDPATH**/ ?>