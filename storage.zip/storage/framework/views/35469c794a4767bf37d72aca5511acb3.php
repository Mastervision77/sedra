<!doctype html>
<html lang="ar" dir="ltr">

<!--!--------------- Header Start -->
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!--!--------------- Header End -->

<body>

    <!--!--------------- Navbar Start -->
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--!--------------- Navbar End -->

    <?php echo $__env->yieldContent('content'); ?>

    <!--//-------------- Footer Start -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--//-------------- Footer End -->

    <!--//-------------- Scripts Start -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--//-------------- Scripts End -->


</body>

</html>
<?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/layouts/app.blade.php ENDPATH**/ ?>