<?php
$setting = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($package && $package->subtitle != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$package->subtitle), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('og_title', @$setting->sitename . " | ".$package->title); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($package && $package->subtitle != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$package->subtitle), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('title', @$setting->sitename . " | ".$package->title); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('content'); ?>

<div class="relative h-[60vh] overflow-hidden">
    <img src="<?php echo e(asset('storage/'.$package->innerimage)); ?>" alt="<?php echo e($package->title); ?>"
        class="w-full h-full object-cover">
    <div class="absolute inset-0 bg-gradient-to-t from-accent/70 via-accent/40 to-transparent"></div>
    <div class="absolute bottom-0 left-0 right-0 container mx-auto px-4 pb-12 text-primary">
        <div class="flex items-center gap-2 text-primary mb-4">
            
            
        </div>
        <h1 class="text-5xl md:text-7xl font-bold mb-4"><?php echo e($package->title); ?></h1>
        <div class="flex flex-wrap gap-6 text-lg">
            <div class="flex items-center gap-2">
                <i class="fa-solid fa-calendar-days"></i>
                <span><?php echo e($package->duration); ?></span>
            </div>
            <div class="flex items-center gap-2">
                <i class="fa-solid fa-users"></i>
                <span><?php echo e($package->people_number); ?></span>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="container mx-auto px-4 py-16 grid grid-cols-1 lg:grid-cols-3 gap-12">

    <!-- Left Column -->
    <div class="lg:col-span-2">

        <!-- Package Overview -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6">Package Overview</h2>
            <p class="text-lg text-gray-700 leading-relaxed"><?php echo $package->overview; ?></p>
        </section>

        <!-- Gallery -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6">Gallery</h2>
            <div class="swiper gallerySwiper">
                <div class="swiper-wrapper">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="swiper-slide relative h-64 rounded-lg overflow-hidden group">
                        <img src="<?php echo e(asset('storage/'.$img)); ?>" alt="Gallery Image"
                            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No gallery images available.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Itinerary -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6">Day-by-Day Itinerary</h2>
            <div class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->itinerary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white rounded-lg shadow">
                    <div class="p-6 flex gap-4">
                        <div
                            class="flex-shrink-0 w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                            <span class="text-2xl font-bold text-primary"><?php echo e($item['day']); ?></span>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold mb-2"><?php echo e($item['title']); ?></h3>
                            <p class="text-gray-700"><?php echo $item['content']; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">Itinerary details not available.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <!-- Included / Not Included -->
        <section class="mb-12 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <h3 class="text-2xl font-bold mb-6">What's Included</h3>
                <ul class="space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->includes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex items-start gap-3">
                        <i class="fa-solid fa-check text-green-600 mt-1"></i>
                        <span><?php echo e($inc['item']); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>No included items available.</li>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
            <div>
                <h3 class="text-2xl font-bold mb-6">What's Not Included</h3>
                <ul class="space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->notincludes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notinc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex items-start gap-3">
                        <i class="fa-solid fa-xmark text-red-600 mt-1"></i>
                        <span><?php echo e($notinc['item']); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>No exclusions listed.</li>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
        </section>

        <!-- Pricing -->
        <section class="mb-12">
            <h2 class="text-3xl font-bold mb-6">Pricing</h2>
            <table class="w-full border-collapse">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b">
                    <td class="p-4 font-medium"><?php echo e($price['title']); ?></td>
                    <td class="p-4 text-right text-2xl font-bold text-primary">$<?php echo e($price['price']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" class="p-4 text-center text-gray-500">Pricing not available.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </table>
        </section>

        <!-- Payment Terms -->
        <section>
            <h2 class="text-3xl font-bold mb-6">Payment Terms</h2>
            <ul class="space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $package->payterms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex items-start gap-3">
                    <div class="w-2 h-2 rounded-full bg-primary mt-2"></div>
                    <span class="text-gray-700"><?php echo e($term['item']); ?></span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No payment terms available.</li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </section>

    </div>

    <!-- Sidebar -->
    <div>
        <div class="sticky top-24 bg-white shadow p-6 rounded-lg">
            <div class="text-center mb-6">
                <p class="text-gray-500 mb-2">Starting from</p>
                <p class="text-5xl font-bold text-primary">$<?php echo e($package->price); ?></p>
                <p class="text-sm text-gray-500 mt-1">per person</p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <script>
                Swal.fire({
                                            title: 'Thanks for contacting us '
                                            , text: '<?php echo e(session('
                                            success ')); ?>'
                                            , icon: 'success'
                                            , confirmButtonText: 'Done'
                                            , confirmButtonColor: '#3085d6'
                                        , });

            </script>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <script>
                Swal.fire({
                                    title: ' There is an error 😢'
                                    , html: `<?php echo implode('<br>', $errors->all()); ?>`
                                    , icon: 'error'
                                    , confirmButtonText: 'Done'
                                    , confirmButtonColor: '#d33'
                                , });
            </script>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <!-- Inquiry Form -->
            <form method="POST" action="<?php echo e(route('tripbooking')); ?>" class="space-y-4">
                <?php echo csrf_field(); ?>

                <div>
                    <label class="text-sm text-gray-600">Name</label>
                    <input type="text" name="name" placeholder="Your Name" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-none focus:border-primary">
                </div>
                <div>
                    <label class="text-sm text-gray-600">Phone</label>
                    <input type="number" min="0" name="phone" placeholder="Your Phone" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-none focus:border-primary">
                </div>
                <div>
                    <label class="text-sm text-gray-600">Package</label>
                    <input type="text" name="tripname" value="<?php echo e($package->title); ?>" readonly
                        class="w-full bg-gray-100 border border-gray-300 rounded-lg px-3 py-2 mt-1 cursor-not-allowed">
                </div>

                <button type="submit"
                    class="w-full bg-primary text-white py-3 rounded-lg font-semibold hover:bg-primary/90 transition">
                    Submit Inquiry
                </button>
            </form>

            <div class="mt-6 pt-6 border-t border-gray-200 text-center">
                <h4 class="font-semibold mb-3">Need Help?</h4>
                <p class="text-sm text-gray-700 mb-4">Our travel experts are ready to assist you with any questions.</p>
                <a href="<?php echo e(route('contact')); ?>">
                    <button class="w-full border border-gray-300 py-2 rounded-lg">Contact Us</button>
                </a>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/packagedetails.blade.php ENDPATH**/ ?>