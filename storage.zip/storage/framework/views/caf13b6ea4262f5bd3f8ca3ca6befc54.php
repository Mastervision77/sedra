<?php
$setting = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($faqs && $faqs->first()->title != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$faqs->first()->title), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('og_title', @$setting->sitename . " | "."FAQs"); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($faqs && $faqs->first()->title != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$faqs->first()->title), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->umrahcover != null): ?>
<?php $__env->startSection('og_image'); ?><?php echo e(asset('storage/' . $setting->umrahcover)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('title', @$setting->sitename . " | "."FAQs"); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<?php $__env->startSection('content'); ?>

<!-- Main -->
<main class="pt-11 md:pt-28 pb-20 bg-accent">
    <div class="container mx-auto px-4">

        <!-- Page Header -->
        <div class="text-center mb-16">
            <h1 class="text-5xl font-PlayFair font-bold mb-6">Frequently Asked Questions</h1>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                Find answers to common questions about traveling with Sedra Travel
            </p>
        </div>

        <!-- FAQ Sections -->
        <!-- FAQ Sections -->
        <div class="max-w-4xl mx-auto space-y-12">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h2 class="text-3xl font-bold mb-6">
                    <?php echo e($section['title']); ?>

                </h2>

                <div class="space-y-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $section['faq']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <details class="border rounded-lg p-6 shadow hover:shadow-md transition-all duration-300">
                        <summary class="font-semibold text-lg">
                            <?php echo e($item['faq_title'] ?? 'Question'); ?>

                        </summary>

                        <p class="mt-4 text-gray-700">
                            <?php echo e($item['answer'] ?? 'Answer goes here'); ?>

                        </p>
                    </details>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <!-- Contact Card -->
            <div class="max-w-3xl mx-auto mt-16 bg-accent shadow-lg rounded-xl p-12 text-center">
                <h2 class="text-3xl font-bold mb-4">Still Have Questions?</h2>
                <p class="text-lg text-gray-600 mb-8">
                    Can't find the answer you're looking for? Our friendly team is here to help.
                </p>
                <a href="#"
                    class="inline-block px-8 py-4 bg-primary text-accent rounded-lg font-semibold hover:bg-gold transition-colors">
                    Contact Us
                </a>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/faq.blade.php ENDPATH**/ ?>