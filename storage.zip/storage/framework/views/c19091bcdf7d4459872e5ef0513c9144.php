<?php
$settings = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($contacts && $contacts->title != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$contacts->title), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($settings && $settings->sitename != null): ?>
<?php $__env->startSection('og_title', @$settings->sitename . " | "."Contact Us"); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($contacts && $contacts->title != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$contacts->title), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($settings && $settings->sitename != null): ?>
<?php $__env->startSection('title', @$settings->sitename . " | "."Contact Us"); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<?php $__env->startSection('content'); ?>
<!--  Contact Page Content  -->
<section class="pt-11 md:pt-28 pb-20 bg-accent">
    <div class="container px-4">

        <!-- Title -->
        <div class="text-center mb-16">
            <h1 class="text-5xl md:text-6xl font-PlayFair font-bold mb-6">Contact Us</h1>
            <p class="text-xl text-gray-500 max-w-2xl mx-auto">
                <?php echo e($contacts->title); ?>

            </p>
        </div>

        <!-- Contact Info Cards -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">

            <!-- Phone -->
            <div class="shadow-lg rounded-lg p-6 text-center">
                <div class="w-16 h-16 rounded-full bg-gold/40 flex items-center justify-center mx-auto mb-4">
                    <i class="fa-solid fa-phone text-primary text-2xl"></i>
                </div>
                <h3 class="font-bold text-lg mb-2">Phone</h3>
                
                <p class="font-semibold"><?php echo e($contacts->phone); ?></p>
            </div>

            <!-- Email -->
            <div class="shadow-lg rounded-lg p-6 text-center">
                <div class="w-16 h-16 rounded-full bg-gold/40 flex items-center justify-center mx-auto mb-4">
                    <i class="fa-solid fa-envelope text-primary text-2xl"></i>
                </div>
                <h3 class="font-bold text-lg mb-2">Email</h3>
                
                <p class="font-semibold"><?php echo e($contacts->email); ?></p>
            </div>

            <!-- WhatsApp -->
            <div class="shadow-lg rounded-lg p-6 text-center">
                <div class="w-16 h-16 rounded-full bg-gold/40 flex items-center justify-center mx-auto mb-4">
                    <i class="fa-brands fa-whatsapp text-primary text-2xl"></i>
                </div>
                <h3 class="font-bold text-lg mb-2">WhatsApp</h3>
                
                <a href="https://wa.me/<?php echo e($contacts->whatsapp); ?>" target="_blank"
                    class="inline-block mt-3 px-4 py-2 border border-black rounded hover:bg-gold/40 hover:text-primary transition">
                    Chat on WhatsApp
                </a>
            </div>
        </div>

        <!-- Contact Form + Locations -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <script>
                Swal.fire({
                                title: 'Thanks for contacting us '
                                , text: '<?php echo e(session('
                                success ')); ?>'
                                , icon: 'success'
                                , confirmButtonText: 'Done'
                                , confirmButtonColor: '#3085d6'
                            , });

            </script>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                <script>
                    Swal.fire({
                        title: ' There is an error 😢'
                        , html: `<?php echo implode('<br>', $errors->all()); ?>`
                        , icon: 'error'
                        , confirmButtonText: 'Done'
                        , confirmButtonColor: '#d33'
                    , });
                </script>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <!-- Form -->
            <div>
                <h2 class="text-3xl font-bold mb-6">Send us a Message</h2>
                <form action="<?php echo e(route('send')); ?>" method="POST" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block text-sm font-medium mb-2" name="name">Full Name *</label>
                        <input name="name" required class="w-full border border-black bg-accent rounded p-3 " type="text" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-2">Email Address </label>
                        <input type="email" name="email"  class="w-full border border-black bg-accent rounded p-3" type="email" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-2">Phone Number *</label>
                        <input type="number" name="primaryPhone" min="0" required class="w-full border border-black bg-accent rounded p-3" type="tel">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Message *</label>
                        <textarea required name="message" class="w-full border border-black bg-accent rounded p-3" rows="6" required></textarea>
                    </div>

                    <button type="submit" class="w-full bg-black text-white py-3 rounded hover:bg-gold transition">
                        Send Message
                    </button>
                </form>
            </div>

            <!-- Locations -->
            <div>
                <h2 class="text-3xl font-bold mb-6">Our Locations</h2>

                <div class="space-y-6 mb-8">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $contacts->location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="shadow-lg rounded-lg p-6 flex gap-4">
                            <i class="fa-solid fa-location-dot text-primary text-xl mt-1"></i>
                            <div>
                                <h3 class="font-bold text-lg mb-1"><?php echo e($location['title']); ?></h3>
                                <p class="text-gray-500"><?php echo e($location['location']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Google Map -->
                <div class="w-full h-64 rounded-lg overflow-hidden shadow-lg">
                    <iframe
                        src="<?php echo e($contacts->map); ?>"
                        width="100%" height="100%" style="border:0;" loading="lazy">
                    </iframe>
                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/contact.blade.php ENDPATH**/ ?>