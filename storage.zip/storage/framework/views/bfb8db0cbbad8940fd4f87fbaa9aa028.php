<!-- Footer Section -->

<?php
$setting = App\Models\Settings::first();
?>

<footer class="bg-primary text-accent pt-12 pb-2">
    <div class="container mx-auto px-4">
        <div class="grid md:grid-cols-3 gap-8 mb-8">
            <!-- Logo and Description -->
            <div class="space-y-4">
                <div class="flex items-center gap-1">
                    <img src="<?php echo e(asset('storage/'.$setting->footerlogo)); ?>" class="w-32 h-11" alt="sedra Travel">
                </div>
                <p class="font-Lora text-accent/70 text-sm leading-relaxed">
                    <?php echo e(@$setting->descriptionfooter); ?>

                </p>
            </div>

            <!-- Quick Links -->
            <div>
                <h3 class="font-PlayFair text-lg font-bold mb-4">Quick Links</h3>
                <ul class="space-y-2 font-Lora text-sm">
                    <li><a href="<?php echo e(route('about')); ?>" class="text-accent/70 hover:text-gold transition-colors">About
                            Us</a>
                    </li>
                    <li><a href="<?php echo e(route('faq')); ?>" class="text-accent/70 hover:text-gold transition-colors">FAQ</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>"
                            class="text-accent/70 hover:text-gold transition-colors">Contact</a>
                    </li>
                    <li><a href="<?php echo e(route('packages')); ?>"
                            class="text-accent/70 hover:text-gold transition-colors">Packages</a>
                    </li>
                    <li><a href="<?php echo e(route('destination')); ?>"
                            class="text-accent/70 hover:text-gold transition-colors">Destinations</a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div>
                <h3 class="font-PlayFair text-lg font-bold mb-4">Get in Touch</h3>
                <ul class="space-y-2 font-Lora text-sm text-accent/70">
                    <li><a href="tel:+1234567890" class="hover:text-gold transition-colors"> <?php echo e(@$setting->phone); ?></a>
                    </li>
                    <li><a href="mailto:<?php echo e(@$setting->mail); ?>" class="hover:text-gold transition-colors">
                            <?php echo e(@$setting->mail); ?></a>
                    </li>
                    <li class="pt-4">
                        <div class="flex gap-4">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $setting->social_midea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(@$social['url']); ?>"
                                    target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors"
                                    aria-label="Visit our Instagram">
                                    <i class="<?php echo e(@$social['platform']); ?> text-[20px]"></i>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <div class="container h-px w-full bg-accent/20 mb-2"></div>

        <!-- Footer Bottom -->
        <div class="text-center text-xs text-accent/60">
            Copyright © 2025 Sedra Travel . All Right Reserved. Powered By
            <a href="https://www.mv-is.com/" target="_blank">
                Master Vision Integrated Solutions
            </a> &
            <a href="https://www.wedo-eg.com/en" target="_blank">
                We Do
            </a>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/layouts/footer.blade.php ENDPATH**/ ?>