<?php
$settings = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($about && $about->content != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$about->content), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($settings && $settings->sitename != null): ?>
<?php $__env->startSection('og_title', @$settings->sitename . " | "."About Us"); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($about && $about->content != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$about->content), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($settings && $settings->sitename != null): ?>
<?php $__env->startSection('title', @$settings->sitename . " | "."About Us"); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->startSection('content'); ?>
<!-- Main Page -->
<main class="pt-11 md:pt-28 pb-20 bg-accent">
    <div class="container mx-auto px-4">
        <div class="max-w-5xl mx-auto">

            <!-- Title -->
            <div class="text-center mb-16">
                <h1 class="text-5xl font-PlayFair font-bold text-primary mb-6">About Us</h1>
                <p class="text-lg text-gray-600 max-w-3xl mx-auto">
                  <?php echo e($about->title); ?>

                </p>
            </div>

            <!-- About Content -->
            <section class="space-y-6 text-gray-700 text-lg leading-relaxed mb-16">
                <p>
                    <?php echo $about->content; ?>

                </p>

            </section>

            <!-- Vision & Mission -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
                <div class="bg-accent/40 border border-gold p-8 rounded-xl shadow-md">
                    <h3 class="text-3xl font-PlayFair font-bold text-primary mb-4">Our Vision</h3>
                    <p class="text-gray-700 leading-relaxed">
                        <?php echo $about->vision; ?>

                    </p>
                </div>

                <div class="bg-accent/40 border border-gold p-8 rounded-xl shadow-md">
                    <h3 class="text-3xl font-PlayFair font-bold text-primary mb-4">Our Mission</h3>
                    <p class="text-gray-700 leading-relaxed">
                        <?php echo $about->mission; ?>

                    </p>
                </div>
            </div>

            <!-- What We Offer -->
            <section class="mb-20">
                <h2 class="text-3xl font-PlayFair font-bold text-center text-primary mb-10">What We Offer</h2>
                <ul class="list-disc pl-8 space-y-3 text-gray-700 text-lg">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $about->offer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($offer['item']); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </section>

            <!-- Why Choose Us? -->
            <section class="mb-20">
                <h2 class="text-3xl font-PlayFair font-bold text-center text-primary mb-10">Why Choose Us?</h2>
                <ol class="list-decimal pl-8 space-y-4 text-gray-700 text-lg">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $about->whychoose; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whychoose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($whychoose['item']); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ol>
            </section>

            <!-- Official Documents Slider -->
            <section class="mb-20">
                <h2 class="text-3xl font-PlayFair font-bold text-center text-primary mb-10">Official Company
                    Documents</h2>

                <!-- Swiper -->
                <div class="swiper myDocsSwiper w-full max-w-4xl mx-auto">
                    <div class="swiper-wrapper">
                        <!-- Slide 1 -->
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $about->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Trade License"
                                    class="rounded-xl w-full h-[350px] object-contain">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>





                    </div>


                    <!-- Pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </section>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/about.blade.php ENDPATH**/ ?>