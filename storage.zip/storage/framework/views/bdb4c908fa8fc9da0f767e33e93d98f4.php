<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>