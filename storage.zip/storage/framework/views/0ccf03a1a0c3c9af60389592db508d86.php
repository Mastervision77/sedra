<?php
$setting = App\Models\Settings::first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($packages && $packages->first()->title != null): ?>

<?php $__env->startSection('meta_description'); ?><?php echo \Str::limit(strip_tags(@$packages->first()->title), 160); ?><?php $__env->stopSection(); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('og_title', @$setting->sitename . " | "."Destinations"); ?>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($packages && $packages->first()->title != null): ?>
<?php $__env->startSection('og_description'); ?><?php echo e(\Str::limit(strip_tags(@$packages->first()->title), 160)); ?><?php $__env->stopSection(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



<?php $__env->startSection('og_url', url()->current()); ?>

<?php $__env->startSection('og_type', 'website'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($setting && $setting->sitename != null): ?>
<?php $__env->startSection('title', @$setting->sitename . " | "."Destinations"); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<?php $__env->startSection('content'); ?>

<main class="pt-11 md:pt-28 pb-20 bg-accent">
    <div class="container px-4">
        <div class="text-center mb-16">
            <h1 class="text-5xl font-bold mb-6 font-PlayFair"><?php echo e($setting->title_blog_page); ?></h1>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                <?php echo e($setting->sub_title_blog_page); ?>

            </p>
        </div>

        <!-- Start Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

            <!-- Card 1 -->

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('packageshow',$package->slug)); ?>"
                    class="group bg-white rounded-lg overflow-hidden shadow hover:shadow-xl transition flex flex-col">
                    <div class="relative h-64 overflow-hidden">
                        <img src="<?php echo e(asset('storage/'.$package->outerimage)); ?>"
                            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        <div class="absolute top-4 right-4 bg-primary text-white px-4 py-2 rounded-full font-semibold">
                            From $<?php echo e($package->price); ?>

                        </div>
                    </div>
                    <div class="p-6 flex flex-col flex-1">
                        <p class="flex items-center gap-2 text-gray-500 text-sm mb-2">
                            <i class="fa-solid fa-map-pin"></i> <?php echo e($package->location); ?>

                        </p>
                        <h3 class="text-2xl font-bold mb-3"><?php echo e($package->title); ?></h3>
                        <p class="text-gray-600 flex-1 mb-4 max-lines-card"><?php echo e($package->subtitle); ?></p>

                        <div class="flex items-center justify-between border-t pt-4 text-gray-500 text-sm">
                            <span><i class="fa-solid fa-stopwatch"></i> <?php echo e($package->duration); ?> </span>
                            <span><i class="fa-solid fa-users"></i> <?php echo e($package->people_number); ?> </span>
                        </div>

                        <button class="w-full mt-4 bg-primary text-white py-2 rounded-md hover:bg-gray-800 transition">
                            View Details
                        </button>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        </div>
        <!-- Pagination -->
        
        <div class="flex justify-center mt-12 custom-pagination">
           <?php echo e($packages->links()); ?>

        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\MV\Sedra\Sedra\resources\views/pages/packages.blade.php ENDPATH**/ ?>